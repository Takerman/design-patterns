﻿namespace Iterator
{
    public class Iterator
    {
    }
}