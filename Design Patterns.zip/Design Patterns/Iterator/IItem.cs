﻿namespace Iterator
{
    public interface IItem
    {
    }
}