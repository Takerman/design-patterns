﻿namespace Iterator
{
    public interface IInventory
    {
        IInventoryIterator GetInventoryIterator();
    }
}