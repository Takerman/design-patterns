﻿namespace Iterator
{
    public class Item : IItem
    {
    }
}