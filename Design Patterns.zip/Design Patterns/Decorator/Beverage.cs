﻿namespace Takerman.DesignPatterns.DecoratorPattern
{
    public abstract class Beverage
    {
        public abstract int Cost();
    }
}
