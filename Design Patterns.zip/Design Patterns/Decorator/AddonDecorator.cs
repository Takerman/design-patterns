﻿namespace Takerman.DesignPatterns.DecoratorPattern
{
    public abstract class AddonDecorator
    {
        public abstract int Cost();
    }
}
