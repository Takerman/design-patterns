﻿namespace Takerman.DesignPatterns.AdapterPattern
{
    internal interface ITarget
    {
        void Request();
    }
}
