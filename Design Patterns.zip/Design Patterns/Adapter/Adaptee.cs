﻿namespace Takerman.DesignPatterns.AdapterPattern
{
    public class Adaptee
    {
        public void SpecificRequest()
        {

        }
    }
}
