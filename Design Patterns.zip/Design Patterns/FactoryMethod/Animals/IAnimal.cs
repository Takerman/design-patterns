﻿namespace Takerman.DesignPatterns.FactoryPattern.Animals
{
    public interface IAnimal
    {
        string MakeSound();
    }
}
