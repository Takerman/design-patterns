﻿namespace Takerman.DotNetCore.StrategyPattern
{
    public interface IFlyBehaviour
    {
        void Fly();
    }
}