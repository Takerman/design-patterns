﻿namespace Takerman.DotNetCore.StrategyPattern
{
    public interface IQuackBehaviour
    {
        void Quack();
    }
}