﻿namespace Takerman.DotNetCore.StrategyPattern
{
    public interface IDisplayBehaviour
    {
        void Display();
    }
}