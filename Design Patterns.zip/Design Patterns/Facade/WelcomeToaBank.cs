﻿using System;

namespace Takerman.DesignPattern.FacadePattern
{
    public class WelcomeToBank
    {
        public WelcomeToBank()
        {
            Console.WriteLine("Welcome to ABC Bank");
        }
    }
}
