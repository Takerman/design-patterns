﻿namespace Takerman.DesignPatterns.ObserverPattern
{
    public interface IObserver
    {
        void Update();
    }
}