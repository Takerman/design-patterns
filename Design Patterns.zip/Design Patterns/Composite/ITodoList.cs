﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Composite
{
    public interface ITodoList
    {
        string GetHtml();
    }
}
