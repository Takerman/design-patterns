﻿using System;

namespace StateObject
{
    public class CloseGateState : GateState
    {
        public void Enter()
        {
            throw new NotImplementedException();
        }

        public void Pay()
        {
            throw new NotImplementedException();
        }

        public void PayFailed()
        {
            throw new NotImplementedException();
        }

        public void PayOn()
        {
            throw new NotImplementedException();
        }
    }
}