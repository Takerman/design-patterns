﻿namespace Takerman.DesignPatterns.CommandPattern
{
    public class Receiver
    {
        public void On()
        {

        }

        public void Off()
        {

        }
    }
}
