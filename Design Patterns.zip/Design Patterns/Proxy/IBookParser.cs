﻿namespace Takerman.DesignPatterns.Proxy
{
    public interface IBookParser
    {
        int GetNumPages();
    }
}
