﻿namespace Takerman.DesignPatterns.AbstractFactory
{
    public abstract class ProductA
    {
    }
}