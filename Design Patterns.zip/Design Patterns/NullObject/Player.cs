﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NullObject
{
    public class Player
    {
        public IMovingBihaviour MovingBihaviour { get; set; }
    }
}
