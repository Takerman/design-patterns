﻿namespace NullObject
{
    public interface IMovingBihaviour
    {
        void GoUp();
        void GoDown();
        void GoLeft();
        void GoRight();
    }
}